<?php
$result = 'no data';
$status = 'no data';
// Validate the incoming request
$validatedData = $request->validate([
    'for' => 'required',
]);
$random_number = rand(100000, 999999);
$real_state = $validatedData['for'];
if ($real_state == "send") {
    $validatedData = $request->validate([
        'phone' => 'required',
    ]);
    require_once(base_path('vendor/autoload.php'));

    // Create an instance of the SmsApi class
    $api_instance = new NotifyLk\Api\SmsApi();
    $real_phone = '94' . intval($validatedData['phone']);
    // Set the required parameters for the SMS API
    $userId = "26966"; // Your API User ID
    $apiKey = "ptNStEZ36U7Yogkk5UnX"; // Your API Secret
    $message = "Your GTS Verification Code is" . " " . $random_number; // Message text
    $to = $real_phone; // Use the validated phone number from the request
    $senderId = "GTSOTP"; // Sender ID

    // Send the SMS and handle any exceptions
    try {
        $api_instance->sendSMS($userId, $apiKey, $message, $to, $senderId);
        $hashed_result = hash('sha256', (string)$random_number);
        $result = $hashed_result;
    } catch (Exception $e) {
        $result = 'Exception when calling SmsApi->sendSMS: ' . $e->getMessage();
    }
}
if ($real_state == 'check') {
    $validatedData_code = $request->validate([
        'code' => 'required',
        'gtscode' => 'required'
    ]);
    $verify_code_is = $validatedData_code['code'];
    $hashed_code = $validatedData_code['gtscode'];
    $check_with_code_is = hash('sha256', (string)$verify_code_is);
    if ($hashed_code == $check_with_code_is) {
        $status = 'Verified';
    } else {
        $status = 'Try Again';
    }
}
